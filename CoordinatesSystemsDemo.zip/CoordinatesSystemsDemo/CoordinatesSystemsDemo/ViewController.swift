//
//  ViewController.swift
//  CoordinatesSystemsDemo
//
//  Created by Musku,Varun Reddy on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageViewoutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = imageViewoutlet.frame.minX;
        let minY = imageViewoutlet.frame.minY;
        print("(\(minX),\(minY))");

        let maxX = imageViewoutlet.frame.maxX;
        let maxY = imageViewoutlet.frame.maxY;
        print("(\(maxX),\(maxY))");
        
        
        let midX = imageViewoutlet.frame.midX;
        let midY = imageViewoutlet.frame.midY;
        print("(\(midX),\(midY))");
        
//        imageViewoutlet.frame.origin.x = 0
//        imageViewoutlet.frame.origin.y = 0
        
//        imageViewoutlet.frame.origin.x = 314
//        imageViewoutlet.frame.origin.y = 0

//        imageViewoutlet.frame.origin.x = 0
//        imageViewoutlet.frame.origin.y = 796
//
//        imageViewoutlet.frame.origin.x = 314
//        imageViewoutlet.frame.origin.y = 796
        
        imageViewoutlet.frame.origin.x = 207-50
        imageViewoutlet.frame.origin.y = 448-50

    }

   
}

