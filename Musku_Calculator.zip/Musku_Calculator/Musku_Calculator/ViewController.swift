//
//  ViewController.swift
//  Musku_Calculator
//
//  Created by Musku,Varun Reddy on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var DisplayLayout: UILabel!
    
    @IBOutlet weak var AC: UIButton!
    
    @IBOutlet weak var DisplayLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonAC(_ sender: Any) {
        
    }
    @IBAction func ButtonC(_ sender: Any) {
        
    }
    @IBAction func ButtonModule(_ sender: Any) {
        
    }
    @IBAction func ButtonMultiply(_ sender: Any) {
        
    }
    @IBAction func ButtonPlus(_ sender: Any) {
        DisplayLable.text = "+"
        
    }
    @IBAction func ButtonMinus(_ sender: Any) {
        
    }
    @IBAction func Buttondivision(_ sender: Any) {
        
    }
    @IBAction func Button9(_ sender: Any) {
        
    }
    @IBAction func Button8(_ sender: Any) {
        
    }
    @IBAction func Button7(_ sender: Any) {
        
    }
    @IBAction func Button6(_ sender: Any) {
        
    }
    @IBAction func Button5(_ sender: Any) {
        
    }
    @IBAction func Button4(_ sender: Any) {
        
    }
    @IBAction func Button3(_ sender: Any) {
        
    }
    @IBAction func Button2(_ sender: Any) {
        
    }
    @IBAction func Button1(_ sender: Any) {
        
    }
    @IBAction func Button0(_ sender: Any) {
        
    }
    @IBAction func ButtonDot(_ sender: Any) {
        
    }
    @IBAction func ButtonEquals(_ sender: Any) {
        
    }
    
    
    
}

