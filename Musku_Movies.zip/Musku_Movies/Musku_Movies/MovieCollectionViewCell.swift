//
//  MovieCollectionViewCell.swift
//  Musku_Movies
//
//  Created by Musku,Varun Reddy on 4/21/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
}
