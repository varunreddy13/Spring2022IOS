//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Musku,Varun Reddy on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayImage: UIImageView!
    
    
    @IBOutlet weak var CrsNumber: UILabel!
    
    @IBOutlet weak var CrsTitle: UILabel!
    
    @IBOutlet weak var CrsOffered: UILabel!
    
    @IBOutlet weak var PreviousButton: UIButton!
    
    @IBOutlet weak var NextButton: UIButton!
    
    let courses = [["img01", "44555", "Network Security", "Fall 2022"],["img02", "44643", "Network Security", "Fall 2022"],["img03", "44656", "Network Security", "Fall 2022"]]
    
    var imageNumber = 0;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //The details of the course
        DisplayImage.image = UIImage(named: courses[0][0])
        CrsNumber.text = courses[0][1]
        CrsTitle.text = courses[0][2]
        CrsOffered.text = courses[0][3]
        
    }
    
    
    @IBAction func PreviousButtonClicked(_ sender: UIButton) {
        
        // next button should be enabled
        NextButton.isEnabled = true
        
        // update course detail by decrementing
        imageNumber -= 1
        updateUI(imageNumber)
        
        // previous button should be disable once yo reach the begining
        
        if(imageNumber == 0) {
            
            PreviousButton.isEnabled = false
        }
        
        
    }
    
    
    @IBAction func NextButtonClicked(_ sender: UIButton) {
        
//        func updateUI(imageNum:Int){
//
//            DisplayImage.image = UIImage(named: courses[imageNum][0])
//            CrsNumber.text = courses[imageNum][1]
//            CrsTitle.text = courses[imageNum][2]
//            CrsOffered.text = courses[imageNum][3]
        
        // update the Ui of next course by incrementing image number
        
        imageNumber += 1
        updateUI( imageNumber)
        
        //next button should be disabled once you reach end of the array
        
        if(imageNumber == courses.count-1){
            
            NextButton.isEnabled = false
        }
        
        
        
            
            
        }
        
        func updateUI(_ imageNum:Int){
            
            DisplayImage.image = UIImage(named: courses[imageNum][0])
            CrsNumber.text = courses[imageNum][1]
            CrsTitle.text = courses[imageNum][2]
            CrsOffered.text = courses[imageNum][3]
        
        
        
    }
    
}

