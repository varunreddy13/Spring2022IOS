//
//  ViewController.swift
//  Musku_Movies
//
//  Created by Musku,Varun Reddy on 4/21/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var genreTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

